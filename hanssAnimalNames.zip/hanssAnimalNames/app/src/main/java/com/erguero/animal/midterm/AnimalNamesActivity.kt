package com.erguero.animal.midterm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AnimalNamesActivity : AppCompatActivity() {
    // ...

    fun updateAnimalList() {
        // TODO: Implement logic to update the animal list, removing blocked animals
    }

    fun onManageBlockAnimalsClicked() {
        // TODO: Launch ManageBlockActivity
    }
}

class AnimalDetailsActivity : AppCompatActivity() {
    // ...

    fun onBlockAnimalClicked(animalName: String) {
        // TODO: Add the animal to SharedPreferences block list
        // Close the activity and return to AnimalNamesActivity
    }
}

class ManageBlockActivity : AppCompatActivity() {
    // ...

    fun onUnblockAnimalClicked(animalName: String) {
        // TODO: Remove the animal from SharedPreferences block list
        // The list on the current page should be updated to reflect this change.
    }
}
